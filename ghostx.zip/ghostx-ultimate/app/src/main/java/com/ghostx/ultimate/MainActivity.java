package com.ghostx.ultimate;

import android.app.*;
import android.content.Intent;
import android.os.*;
import android.webkit.*;
import androidx.appcompat.app.AppCompatActivity;
import com.chaquo.python.PyObject;
import com.chaquo.python.Python;
import com.chaquo.python.android.AndroidPlatform;

public class MainActivity extends AppCompatActivity {
    private WebView webView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        if (!Python.isStarted()) {
            Python.start(new AndroidPlatform(this));
        }

        webView = findViewById(R.id.webView);
        webView.getSettings().setJavaScriptEnabled(true);
        webView.addJavascriptInterface(new WebAppInterface(this), "Android");

        // بدء خدمة الخلفية
        startService(new Intent(this, GhostService.class));

        // بدء خادم بايثون الداخلي
        new Thread(() -> {
            Python py = Python.getInstance();
            PyObject server = py.getModule("ghost_server");
            server.callAttr("start_server");
        }).start();

        // تحميل لوحة القيادة بعد تأخير بسيط
        new Handler().postDelayed(() -> {
            webView.loadUrl("http://localhost:5000");
        }, 3000);
    }

    public class WebAppInterface {
        Activity mActivity;
        WebAppInterface(Activity activity) { mActivity = activity; }

        @android.webkit.JavascriptInterface
        public void runCommand(String cmd) {
            new Thread(() -> {
                try {
                    Process p = Runtime.getRuntime().exec(cmd);
                    p.waitFor();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }).start();
        }
    }

    public static class GhostService extends Service {
        @Override
        public int onStartCommand(Intent intent, int flags, int startId) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                NotificationChannel ch = new NotificationChannel("ghost", "Ghost", NotificationManager.IMPORTANCE_LOW);
                getSystemService(NotificationManager.class).createNotificationChannel(ch);
            }
            startForeground(1, new NotificationCompat.Builder(this, "ghost")
                    .setContentTitle("GhostX Ultimate")
                    .setContentText("الخدمة تعمل...")
                    .setSmallIcon(android.R.drawable.ic_menu_manage)
                    .build());
            return START_STICKY;
        }

        @Override
        public IBinder onBind(Intent intent) { return null; }
    }
}
